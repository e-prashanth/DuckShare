from pyspark.sql import SparkSession
from pyspark.ml.feature import StringIndexer, VectorAssembler,OneHotEncoder
from pyspark.ml.classification import RandomForestClassifier
from pyspark.ml.evaluation import BinaryClassificationEvaluator
from pyspark.sql.functions import col, lit, when

# Initialize SparkSession
spark = SparkSession.builder \
    .appName("SparkExample") \
    .getOrCreate()

# Your Spark code here...

# After processing data with Spark DataFrame, collect data to the driver node
# For example:
# df = spark.read.csv("data.csv")
# collected_data = df.collect()

# Once you have collected data to the driver node, switch to local Python environment
# Import required libraries
from matplotlib import pyplot as plt
import missingno as msno
import pandas as pd
import numpy as np
import seaborn as sns

# Your further analysis and visualization code using the imported libraries here...
df = spark.read.csv("diabetes_data.csv",sep=";",header = True)

gender_indexer = StringIndexer(inputCol="gender", outputCol="gender_index")
df_indexed = gender_indexer.fit(df).transform(df)

# Perform one-hot encoding on the 'gender_index' column
encoder = OneHotEncoder(inputCols=["gender_index"], outputCols=["gender_encoded"])
df_encoded = encoder.fit(df_indexed).transform(df_indexed)

# Convert other columns to numeric
numeric_cols = ["age", "polyuria", "polydipsia", "sudden_weight_loss", "weakness", "polyphagia",
                "genital_thrush", "visual_blurring", "itching", "irritability", "delayed_healing",
                "partial_paresis", "muscle_stiffness", "alopecia", "obesity"]
for col_name in numeric_cols:
    df_encoded = df_encoded.withColumn(col_name, col(col_name).cast("double"))

# Convert the 'class' column to numeric using StringIndexer
class_indexer = StringIndexer(inputCol="class", outputCol="label")
df_indexed = class_indexer.fit(df_encoded).transform(df_encoded)

# Assemble features
assembler = VectorAssembler(inputCols=["gender_encoded", "age", "polyuria", "polydipsia", "sudden_weight_loss",
                                       "weakness", "polyphagia", "genital_thrush", "visual_blurring", "itching",
                                       "irritability", "delayed_healing", "partial_paresis", "muscle_stiffness",
                                       "alopecia", "obesity"], outputCol="features")
df_assembled = assembler.transform(df_indexed)

# Split data into training and validation sets
(training_data, validation_data) = df_assembled.randomSplit([0.7, 0.3], seed=42)

# Define Random Forest Classifier
rf = RandomForestClassifier(labelCol="label", featuresCol="features")

# Train the Random Forest model
model = rf.fit(training_data)

# Make predictions on the validation set
predictions = model.transform(validation_data)

# Close SparkSession
spark.stop()  
