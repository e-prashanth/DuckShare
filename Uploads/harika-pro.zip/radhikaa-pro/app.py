from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import numpy as np
from tensorflow.keras.models import load_model  # Import functions from mymodel.py

app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'MiniProject'
app.config['MYSQL_CHARSET'] = 'utf8' 
# Initialize MySQL connection
mysql = mysql.connector.connect(
    host=app.config['MYSQL_HOST'],
    user=app.config['MYSQL_USER'],
    password=app.config['MYSQL_PASSWORD'],
    database=app.config['MYSQL_DB'],
    charset=app.config['MYSQL_CHARSET']
)

# Load the trained model
model = load_model('mymodel.h5')  # Assuming load_model loads the model from the file

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.cursor()
        cursor.execute("INSERT INTO users (email, password) VALUES (%s, %s)", (email, password))
        mysql.commit()

        # Redirect to login page after successful registration
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']

        cursor = mysql.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()

        if user:
            # Redirect to diabetes form upon successful login
            return redirect(url_for('diabetes_form'))
        else:
            return 'Invalid email or password!'

    return render_template('login.html')

@app.route('/diabetes_form', methods=['GET', 'POST'])
def diabetes_form():
    if request.method == 'POST':
        # Retrieve form data
        age = int(request.form['age'])
        gender = request.form['gender']
        polyuria = int(request.form['polyuria'])
        polydipsia = int(request.form['polydipsia'])
        sudden_weight_loss = int(request.form['sudden_weight_loss'])
        weakness=int(request.form['weakness'])
        polyphagia=int(request.form['polyphagia'])
        genital_thrush=int(request.form['genital_thrush'])
        visual_blurring = int(request.form['visual_blurring'])
        itching = int(request.form['itching'])
        irritability = int(request.form['irritability'])
        delayed_healing = int(request.form['delayed_healing'])
        partial_paresis = int(request.form['partial_paresis'])
        muscle_stiffness = int(request.form['muscle_stiffness'])
        alopecia = int(request.form['alopecia'])
        obesity = int(request.form['obesity'])
        # Add retrieval for other symptoms here

        # Preprocess the data
        data = np.array([[age, gender, polyuria, polydipsia, sudden_weight_loss, weakness,polyphagia, genital_thrush, visual_blurring, itching, irritability, delayed_healing, partial_paresis, muscle_stiffness, alopecia, obesity]])  # Adjust as needed for other symptoms

        # Make prediction using the model
        prediction = model.predict(data)

        # Process prediction result (you may need to post-process depending on your model output)

        return render_template('prediction_result.html', prediction=prediction)

    return render_template('diabetes_form.html')

if __name__ == '__main__':
    app.run(debug=True)
